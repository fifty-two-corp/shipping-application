<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect()->route('home');
});

Auth::routes();

//Route::get('/home', 'HomeController@index')->name('home');

Route::group(['middleware' => ['auth']], function() {
	Route::get('logout', 'Auth\LoginController@logout');
	Route::get('home', 'HomeController@index')->name('home');
	Route::get('coming-soon','ComingSoonController@index');

	//Profile
	Route::post('profile/photo/store','ProfileController@update_pictures');
	Route::post('profile/update_field','ProfileController@update_field')->name('update_field');
	Route::get('profile/update_password','ProfileController@update_password');
	Route::post('profile/store_password','ProfileController@store_password');
	Route::get('profile','ProfileController@index');

	//Master - Customer
	Route::get('customer/get-customer','Master\CustomerController@getCustomer');
	Route::get('customer/create','Master\CustomerController@create');
	Route::get('customer/get-city/{id}', 'Master\CustomerController@getCity');
	Route::get('customer/get-district/{id}', 'Master\CustomerController@getDistrict');
	Route::post('customer/store','Master\CustomerController@store');
	Route::get('customer/{id}/edit','Master\CustomerController@edit');
	Route::patch('customer/{id}','Master\CustomerController@update');
	Route::delete('customer/{id}','Master\CustomerController@destroy');
	Route::get('customer','Master\CustomerController@index');

	//Master - Employees
	Route::get('employees/get-employees','Master\EmployeesController@getEmployees');
	Route::get('employees/create','Master\EmployeesController@create');
	Route::post('employees/store','Master\EmployeesController@store');
	Route::get('employees/{id}/edit','Master\EmployeesController@edit');
	Route::patch('employees/{id}','Master\EmployeesController@update');
	Route::delete('employees/{id}','Master\EmployeesController@destroy');
	Route::get('employees','Master\EmployeesController@index');

	//Master - Vendor
	Route::get('vendors/get-vendor','Master\VendorController@getVendor');
	Route::get('vendors/create','Master\VendorController@create');
	Route::get('vendors/get-city/{id}', 'Master\VendorController@getCity');
	Route::get('vendors/get-district/{id}', 'Master\VendorController@getDistrict');
	Route::post('vendors/store','Master\VendorController@store');
	Route::get('vendors/{id}/edit','Master\VendorController@edit');
	Route::patch('vendors/{id}','Master\VendorController@update');
	Route::delete('vendors/{id}','Master\VendorController@destroy');
	Route::get('vendors','Master\VendorController@index');

	//Master - Service
	Route::get('service/get-service','Master\ServiceController@getService');
	Route::get('service/create','Master\ServiceController@create');
	Route::post('service/store','Master\ServiceController@store');
	Route::get('service/{id}/edit','Master\ServiceController@edit');
	Route::patch('service/{id}','Master\ServiceController@update');
	Route::delete('service/{id}','Master\ServiceController@destroy');
	Route::get('service','Master\ServiceController@index');
	//Route::resource('service','Master\ServiceController');

	//Master - Vehicle
	Route::get('vehicle/get-vehicle','Master\VehicleController@getVehicle');
	Route::get('vehicle/create','Master\VehicleController@create');
	Route::post('vehicle/store','Master\VehicleController@store');
	Route::get('vehicle/{id}/edit','Master\VehicleController@edit');
	Route::patch('vehicle/{id}','Master\VehicleController@update');
	Route::delete('vehicle/{id}','Master\VehicleController@destroy');
	Route::get('vehicle','Master\VehicleController@index');

	//Master - Shipping Cost
	//Route::get('shipping-cost/get-shipping-cost','Master\VehicleController@getVehicle');
	//Route::get('shipping-cost/create','Master\VehicleController@create');
	//Route::post('shipping-cost/store','Master\VehicleController@store');
	//Route::get('shipping-cost/{id}/edit','Master\VehicleController@edit');
	//Route::patch('shipping-cost/{id}','Master\VehicleController@update');
	//Route::delete('shipping-cost/{id}','Master\VehicleController@destroy');
	//Route::get('shipping-cost','Master\VehicleController@index');

	//Master - City
	Route::get('city/get-city/{id}','Master\CityController@getCity');
	Route::get('city/get-data-city/{id}','Master\CityController@getCityData');
	Route::get('city/get-city-default','Master\CityController@getCityDefault');
	Route::get('city/create-city','Master\CityController@createCity');
	Route::post('city/store-city','Master\CityController@storeCity');
	Route::get('city/{id}/edit-city','Master\CityController@editCity');
	Route::patch('city/{id}','Master\CityController@updateCity');
	Route::delete('city/city/{id}','Master\CityController@destroyCity');
	Route::get('city','Master\CityController@index');

	//Master - Province
	Route::get('city/get-province','Master\CityController@getProvince');
	Route::get('city/create-province','Master\CityController@createProvince');
	Route::post('city/store-province','Master\CityController@storeProvince');
	Route::get('city/{id}/edit-province','Master\CityController@editProvince');
	Route::patch('province/{id}','Master\CityController@updateProvince');
	Route::delete('city/province/{id}','Master\CityController@destroyProvince');
	

	// Administrator - Users
  //Route::get('users','Administrator\UsersController@index');
  Route::get('users/get-user','Administrator\UsersController@getUser');
	Route::post('users/store','Administrator\UsersController@store');
	Route::get('users/{id}/edit','Administrator\UsersController@edit');
	Route::patch('users/{id}','Administrator\UsersController@update');
	Route::delete('users/{id}','Administrator\UsersController@destroy');
	Route::resource('users','Administrator\UsersController');
	/*Route::get('users','Administrator\UsersController@index');
	Route::get('users/create','Administrator\UsersController@create');*/

	// Administrator - Role
	Route::get('roles/get-roles',['as'=>'roles.list','uses'=>'Administrator\RoleController@getRole','middleware' => ['permission:role-list|role-create|role-edit|role-delete']]);
	Route::get('roles',['as'=>'roles.index','uses'=>'Administrator\RoleController@index','middleware' => ['permission:role-list|role-create|role-edit|role-delete']]);
	Route::get('roles/create',['as'=>'roles.create','uses'=>'Administrator\RoleController@create','middleware' => ['permission:role-create']]);
	Route::post('roles/store',['as'=>'roles.store','uses'=>'Administrator\RoleController@store','middleware' => ['permission:role-create']]);
	Route::get('roles/{id}/edit',['as'=>'roles.edit','uses'=>'Administrator\RoleController@edit','middleware' => ['permission:role-edit']]);
	Route::patch('roles/{id}',['as'=>'roles.update','uses'=>'Administrator\RoleController@update','middleware' => ['permission:role-edit']]);
	Route::delete('roles/{id}',['as'=>'roles.destroy','uses'=>'Administrator\RoleController@destroy','middleware' => ['permission:role-delete']]);
	Route::get('roles/{id}',['as'=>'roles.show','uses'=>'Administrator\RoleController@show', 'middleware' => ['permission:role-list']]);
	//Route::patch('roles/{id}','Administrator\RoleController@update');

	//Route::resource('roles','Administrator\RoleController');
	/*Route::get('roles/{id}',['as'=>'roles.show','uses'=>'RoleController@show']);*/


	// Administrator - Permision
	//Route::resource('permision','Administrator\PermisionController');
	Route::get('permision/get-permision','Administrator\PermisionController@getPermision');
	Route::get('permision','Administrator\PermisionController@index');
	Route::get('permision/create','Administrator\PermisionController@create');
	Route::post('permision/store','Administrator\PermisionController@store');
	Route::get('permision/{id}/edit','Administrator\PermisionController@edit');
	Route::patch('permision/{id}','Administrator\PermisionController@update');
	Route::delete('permision/{id}','Administrator\PermisionController@destroy');

	Route::get('itemCRUD2',['as'=>'itemCRUD2.index','uses'=>'ItemCRUD2Controller@index','middleware' => ['permission:item-list|item-create|item-edit|item-delete']]);
	Route::get('itemCRUD2/create',['as'=>'itemCRUD2.create','uses'=>'ItemCRUD2Controller@create','middleware' => ['permission:item-create']]);
	Route::post('itemCRUD2/create',['as'=>'itemCRUD2.store','uses'=>'ItemCRUD2Controller@store','middleware' => ['permission:item-create']]);
	Route::get('itemCRUD2/{id}',['as'=>'itemCRUD2.show','uses'=>'ItemCRUD2Controller@show']);
	Route::get('itemCRUD2/{id}/edit',['as'=>'itemCRUD2.edit','uses'=>'ItemCRUD2Controller@edit','middleware' => ['permission:item-edit']]);
	Route::patch('itemCRUD2/{id}',['as'=>'itemCRUD2.update','uses'=>'ItemCRUD2Controller@update','middleware' => ['permission:item-edit']]);
	Route::delete('itemCRUD2/{id}',['as'=>'itemCRUD2.destroy','uses'=>'ItemCRUD2Controller@destroy','middleware' => ['permission:item-delete']]);
});
