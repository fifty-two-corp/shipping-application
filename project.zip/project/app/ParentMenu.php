<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ParentMenu extends Model {
	protected $table = 'parent_menu';
  public $fillable = ['id','name'];

  public function child_menu() {
      return $this->belongsToMany('App\ChildMenu');
  }

  public function permission() {
      return $this->belongsToMany('App\Permission');
  }
}