<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Zizaco\Entrust\EntrustRole;

class Role extends EntrustRole
{
    public function permission()
    {
        return $this->belongsToMany('App\Permission');
    }

    public function user()
    {
        return $this->belongsToMany('App\User');
    }
}
