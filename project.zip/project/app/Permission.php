<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Zizaco\Entrust\EntrustPermission;

class Permission extends EntrustPermission
{
    public $fillable = ['id','name','display_name','description'];

    public function permission()
    {
        return $this->belongsToMany('App\ChildMenu');
    }

    public function parent_menu()
    {
        return $this->belongsToMany('App\ParentMenu');
    }

    public function roles()
    {
        return $this->belongsToMany('App\Role');
    }
}
