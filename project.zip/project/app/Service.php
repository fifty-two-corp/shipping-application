<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Service extends Model {

  protected $table = 'service';
  public $fillable = ['type_service','unit','unit_price'];

}
