<?php

namespace App\Http\Controllers\Master;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Vendor;
use App\Provinces;
use App\City;
use App\IdMethod;
use DB;
use Datatables;
use Indonesia;

class VendorController extends Controller {
  
	public function index() {
		return view('master/vendor/index');
	}

 	public function getVendor(Request $request) {
 		//if($request->ajax()){
      $vendor = Vendor::all();
 			return Datatables::of($vendor)->make(true);
 	//	} else {
 	//		exit("Not an AJAX request -_-");
 	//	}
 	}

 	public function create() {
    $province = Indonesia::allProvinces()->pluck('name','id');
    return view('master/vendor/modal_add', compact('province'));
 	}

  public function store(Request $request) {
    $this->validate($request, [
      'vendor_number'   => 'required|unique:vendor,vendor_number',
      'name'              => 'required',
      'address'           => 'required',
      'province'          => 'required',
      'city'              => 'required',
      'phone'             => 'required',
    ]);

    $province   = Indonesia::findProvince($request->input('province'))->name;
    $city       = Indonesia::findCity($request->input('city'))->name;
    $districts  = Indonesia::findDistrict($request->input('districts'))->name;

    $vendor = new Vendor();
    $vendor->vendor_number  = $request->input('vendor_number');
    $vendor->name             = $request->input('name');
    $vendor->address          = $request->input('address');
    $vendor->province         = $province;
    $vendor->city             = $city;
    $vendor->districts        = $districts;
    $vendor->phone            = $request->input('phone');
    $vendor->save();

    return response()->json(['responseText' => 'Success'], 200);
    //return response()->json($districts);
  }

  public function getCity($id) {
    $city = Indonesia::findProvince($id, ['cities']);
    $city = $city->cities; 
    return response()->json($city);
  }

  public function getDistrict($id) {
    $districts = Indonesia::findCity($id, ['districts']);
    $districts = $districts->districts;
    return response()->json($districts);
  }

  public function edit($id) {
    $vendor = Vendor::find($id);
    $province = Indonesia::allProvinces()->pluck('name','id');
    
    $vendor_province = DB::table('indonesia_provinces')->where('name', $vendor->province)->get();
    $vendor_province = $vendor_province[0]->id;
    
    $city_vendor = DB::table('indonesia_cities')->where('name', $vendor->city)->get();
    $city_vendor = $city_vendor[0]->id;

    $district_vendor = DB::table('indonesia_districts')->where('name', $vendor->districts)->get();
    $district_vendor = $district_vendor[0]->id;
    
    $city = Indonesia::findProvince($vendor_province, ['cities']);
    $city = $city->cities->pluck('name', 'id');

    $districts = Indonesia::findCity($city_vendor, ['districts']);
    $districts = $districts->districts->pluck('name', 'id');

    return view('master/vendor/modal_edit',compact(
                                                      'vendor', 
                                                      'province', 
                                                      'vendor_province', 
                                                      'city_vendor', 
                                                      'city',
                                                      'district_vendor',
                                                      'districts'
                                                    )
  );
    //return response()->json($city); 
  }

  public function update(Request $request, $id) {

    //$province = Provinces::find($request->input('province'));
    //$province = $province->name;

    $province = Indonesia::findProvince($request->input('province'));
    $province = $province->name;

    $city = Indonesia::findCity($request->input('city'), $with = null);
    $city = $city->name;

    $districts = Indonesia::findDistrict($request->input('districts'), $with = null);
    $districts = $districts->name;
    
    $vendor = Vendor::find($id);

    $this->validate($request, [
      'vendor_number'   => 'required | unique:vendor,vendor_number,'.$vendor->id,
      'name'              => 'required',
      'address'           => 'required',
      'province'          => 'required',
      'city'              => 'required',
      'phone'             => 'required',
    ]);

    $vendor->vendor_number  = $request->vendor_number;
    $vendor->name             = $request->input('name');
    $vendor->address          = $request->input('address');
    $vendor->province         = $province;
    $vendor->city             = $city;
    $vendor->districts        = $districts;
    $vendor->phone            = $request->input('phone');
    $vendor->save();

    return response()->json(['responseText' => 'Updated'], 200);
    //return response()->json($city); 
  }

  public function destroy($id) {
    Vendor::find($id)->delete();
    return response()->json(['responseText' => 'Deleted'], 200);
  }
}
