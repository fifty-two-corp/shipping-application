<?php

namespace App\Http\Controllers\Master;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Service;
use DB;
use Datatables;
use Carbon\Carbon;

class ServiceController extends Controller {
  
	public function index() {
		return view('master/service/index');
	}

 	public function getService(Request $request) {
 		//if($request->ajax())
      $service = Service::all();
 			return Datatables::of($service)
      ->editColumn('created_at', function ($service) {
        return $service->created_at ? with(new Carbon($service->created_at))->format('d M Y') : '';
      })
      ->editColumn('updated_at', function ($service) {
          return $service->updated_at ? with(new Carbon($service->updated_at))->format('d M Y') : '';;
      })
      ->filterColumn('created_at', function ($query, $keyword) {
          $query->whereRaw("DATE_FORMAT(created_at,'%m/%d/%Y') like ?", ["%$keyword%"]);
      })
      ->filterColumn('updated_at', function ($query, $keyword) {
          $query->whereRaw("DATE_FORMAT(updated_at,'%Y/%m/%d') like ?", ["%$keyword%"]);
      })
      ->editColumn('unit_price', function ($service) {
        return $service->unit_price? with("Rp " . number_format($service->unit_price,0,',','.')) : '';
      })
      ->make(true);
 		//} else {
 		//	exit("Not an AJAX request -_-");
 		//}
 	}

 	public function create() {
    return view('master/service/modal_add');
 	}

  public function store(Request $request) {
    $this->validate($request, [
      'type_service' => 'required|unique:service,type_service',
      'unit' => 'required',
      'unit_price' => 'required',
    ]);

    $unit_price = str_replace(".", "", $request->input('unit_price'));
    
    $service = new Service();
    $service->type_service = $request->type_service;
    $service->unit = $request->unit;
    $service->unit_price = $unit_price;
    $service->save();

    return response()->json(['responseText' => 'Success'], 200);
  }

  public function edit($id) {
    $service = Service::find($id);
    return view('master/service/modal_edit',compact('service'));
  }

  public function update(Request $request, $id) {
    
    $service = Service::find($id);
    
    $this->validate($request, [
      'type_service' => 'required|unique:service,type_service,'.$service->id,
      'unit' => 'required',
      'unit_price' => 'required',
    ]);

    $unit_price = str_replace(".", "", $request->input('unit_price'));

    $service->type_service = $request->input('type_service');
    $service->unit = $request->input('unit');
    $service->unit_price = $unit_price;
    $service->save();

    //return response()->json(['responseText' => 'Updated'], 200);
    return response()->json($request);
  }

  public function destroy($id) {
    Service::find($id)->delete();
    return response()->json(['responseText' => 'Deleted'], 200);
  }
}
