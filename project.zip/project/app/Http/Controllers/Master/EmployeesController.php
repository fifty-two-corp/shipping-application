<?php

namespace App\Http\Controllers\Master;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Employees;
use App\Provinces;
use App\City;
use App\IdMethod;
use DB;
use Datatables;

class EmployeesController extends Controller {
  
	public function index() {
		return view('master/employees/index');
	}

 	public function getEmployees(Request $request) {
 		//if($request->ajax())
      $employees = Employees::all();
 			return Datatables::of($employees)->make(true);
 		//} else {
 		//	exit("Not an AJAX request -_-");
 		//}
 	}

 	public function create() {
    $province = Provinces::pluck('name','id');
    $identity_method = IdMethod::pluck('name','name');
    return view('master/employees/modal_add', compact('province', 'identity_method'));
 	}

  public function store(Request $request) {
    
    $this->validate($request, [
      'employees_number'  => 'required|unique:employees,employees_number',
      'name'              => 'required',
      'address'           => 'required',
      'province'          => 'required',
      'city'              => 'required',
      'phone'             => 'required',
      'identity_method'   => 'required',
      'identity_number'   => 'required',
    ]);

    $province = Provinces::find($request->input('province'));
    $province = $province->name;

    $employees = new Employees();
    $employees->employees_number    = $request->input('employees_number');
    $employees->name                = $request->input('name');
    $employees->address             = $request->input('address');
    $employees->province            = $province;
    $employees->city                = $request->input('city');
    $employees->districts           = $request->input('districts');
    $employees->phone               = $request->input('phone');
    $employees->identity_method     = $request->input('identity_method');
    $employees->identity_number     = $request->input('identity_number');
    $employees->save();

    return response()->json(['responseText' => 'Success'], 200);
    //return response()->json($request);
  }

  public function edit($id) {
    $employees = Employees::find($id);
    $province = Provinces::pluck('name','id');
    $identity_method = IdMethod::pluck('name','name');
    $identity = DB::table('identity_method')->where('name', $employees->identity_method)->get();
    $identity = $identity[0]->name;
    
    $employees_province = DB::table('provinces')->where('name', $employees->province)->get();
    $employees_province = $employees_province[0]->id;
    
    $city_employees = DB::table('city')->where('name', $employees->city)->get();
    $city_employees = $city_employees[0]->id;
    
    $city = Provinces::with('city')->where('id', $employees_province)->get();
    $city = $city[0]->city->pluck('name', 'id');

    return view('master/employees/modal_edit',compact('employees', 'province', 'identity_method', 'employees_province', 'city_employees', 'city', 'identity'));
    //return response()->json($city_customer); 
  }

  public function update(Request $request, $id) {

    $province = Provinces::find($request->input('province'));
    $province = $province->name;

    $city = City::find($request->input('city'));
    $city = $city->name;
    
    $employees = Employees::find($id);

    $this->validate($request, [
      'employees_number'  => 'required|unique:employees,employees_number,'.$employees->id,
      'name'              => 'required',
      'address'           => 'required',
      'province'          => 'required',
      'city'              => 'required',
      'phone'             => 'required',
      'identity_method'   => 'required',
      'identity_number'   => 'required',
    ]);

    $employees->employees_number = $request->employees_number;
    $employees->name             = $request->input('name');
    $employees->address          = $request->input('address');
    $employees->province         = $province;
    $employees->city             = $city;
    $employees->districts        = $request->input('districts');
    $employees->phone            = $request->input('phone');
    $employees->identity_method  = $request->input('identity_method');
    $employees->identity_number  = $request->input('identity_number');
    $employees->save();

    return response()->json(['responseText' => 'Updated'], 200);
    //return response()->json($request);
  }

  public function destroy($id) {
    Employees::find($id)->delete();
    return response()->json(['responseText' => 'Deleted'], 200);
  }
}
