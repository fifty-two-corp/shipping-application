<?php

namespace App\Http\Controllers\Master;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Vehicle;
use DB;
use Datatables;
use Carbon\Carbon;

class VehicleController extends Controller {

  public function rules() {

  }
  
	public function index() {
		return view('master/vehicle/index');
	}

 	public function getVehicle(Request $request) {
 		if($request->ajax()) {
      $vehicle = Vehicle::all();
 			return Datatables::of($vehicle)
      ->editColumn('created_at', function ($vehicle) {
        return $vehicle->created_at ? with(new Carbon($vehicle->created_at))->format('d M Y') : '';
      })
      ->editColumn('updated_at', function ($vehicle) {
          return $vehicle->updated_at ? with(new Carbon($vehicle->updated_at))->format('d M Y') : '';;
      })
      ->editColumn('vehicle_tax', function ($vehicle) {
          return $vehicle->vehicle_tax ? with(new Carbon($vehicle->vehicle_tax))->format('d M Y') : '';;
      })
      ->filterColumn('created_at', function ($query, $keyword) {
          $query->whereRaw("DATE_FORMAT(created_at,'%m/%d/%Y') like ?", ["%$keyword%"]);
      })
      ->filterColumn('updated_at', function ($query, $keyword) {
          $query->whereRaw("DATE_FORMAT(updated_at,'%Y/%m/%d') like ?", ["%$keyword%"]);
      })
      ->filterColumn('vehicle_tax', function ($query, $keyword) {
          $query->whereRaw("DATE_FORMAT(vehicle_tax,'%m/%d/%Y') like ?", ["%$keyword%"]);
      })
      ->make(true);
 		} else {
 			exit("Not an AJAX request -_-");
 		}
 	}

 	public function create() {
    return view('master/vehicle/modal_add');
 	}

  public function store(Request $request) {
    $this->validate($request, [
      'name'            => 'required',
      'plat_number'     => 'required',
      'driver'          => 'required',
      'type'            => 'required',
      'merk'            => 'required',
      'color'           => 'required',
      'production_year' => 'required',
      'vehicle_tax'     => 'required',
      'status'          => 'required',
    ]);

    $tax = Carbon::parse($request->input('vehicle_tax'));
    
    $vehicle = new Vehicle();
    $vehicle->name              = $request->name;
    $vehicle->plat_number       = $request->plat_number;
    $vehicle->driver            = $request->driver;
    $vehicle->type              = $request->type;
    $vehicle->merk              = $request->merk;
    $vehicle->color             = $request->color;
    $vehicle->production_year   = $request->production_year;
    $vehicle->vehicle_tax       = $tax;
    $vehicle->status            = $request->status;
    $vehicle->save();

    return response()->json(['responseText' => 'Success'], 200);

    //return response()->json($tax);
  }

  public function edit($id) {
    $vehicle = Vehicle::find($id);
    $vehicle_tax = new Carbon($vehicle->vehicle_tax);
    $vehicle_tax = $vehicle_tax->format('d-m-Y');
    return view('master/vehicle/modal_edit',compact('vehicle', 'vehicle_tax'));
  }

  public function update(Request $request, $id) {
    
    $vehicle = Vehicle::find($id);
    
    $this->validate($request, [
      'name'            => 'required',
      'plat_number'     => 'required',
      'driver'          => 'required',
      'type'            => 'required',
      'merk'            => 'required',
      'color'           => 'required',
      'production_year' => 'required',
      'vehicle_tax'     => 'required',
      'status'          => 'required',
    ]);

    $tax = Carbon::parse($request->input('vehicle_tax'));

    $vehicle->name              = $request->name;
    $vehicle->plat_number       = $request->plat_number;
    $vehicle->driver            = $request->driver;
    $vehicle->type              = $request->type;
    $vehicle->merk              = $request->merk;
    $vehicle->color             = $request->color;
    $vehicle->production_year   = $request->production_year;
    $vehicle->vehicle_tax       = $tax;
    $vehicle->status            = $request->status;
    $vehicle->save();

    return response()->json(['responseText' => 'Updated'], 200);
    //return response()->json($request);
  }

  public function destroy($id) {
    Vehicle::find($id)->delete();
    return response()->json(['responseText' => 'Deleted'], 200);
  }
}
