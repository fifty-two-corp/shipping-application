<?php

namespace App\Http\Controllers\Master;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Customer;
use App\Provinces;
use App\City;
use App\IdMethod;
use DB;
use Datatables;
use Indonesia;

class CustomerController extends Controller {
  
	public function index() {
		return view('master/customer/index');
	}

 	public function getCustomer(Request $request) {
 		if($request->ajax()){
      $customer = Customer::all();
 			return Datatables::of($customer)->make(true);
 		} else {
 			exit("Not an AJAX request -_-");
 		}
 	}

 	public function create() {
    $province = Indonesia::allProvinces()->pluck('name','id');
    return view('master/customer/modal_add', compact('province'));
 	}

  public function store(Request $request) {
    $this->validate($request, [
      'customer_number'   => 'required|unique:customer,customer_number',
      'name'              => 'required',
      'address'           => 'required',
      'province'          => 'required',
      'city'              => 'required',
      'phone'             => 'required',
      'npwp'              => 'required',
    ]);

    $province   = Indonesia::findProvince($request->input('province'))->name;
    $city       = Indonesia::findCity($request->input('city'))->name;
    $districts  = Indonesia::findDistrict($request->input('districts'))->name;

    $customer = new Customer();
    $customer->customer_number  = $request->input('customer_number');
    $customer->name             = $request->input('name');
    $customer->address          = $request->input('address');
    $customer->province         = $province;
    $customer->city             = $city;
    $customer->districts        = $districts;
    $customer->phone            = $request->input('phone');
    $customer->npwp             = $request->input('npwp');
    $customer->save();

    return response()->json(['responseText' => 'Success'], 200);
    //return response()->json($districts);
  }

  public function getCity($id) {
    $city = Indonesia::findProvince($id, ['cities']);
    $city = $city->cities; 
    return response()->json($city);
  }

  public function getDistrict($id) {
    $districts = Indonesia::findCity($id, ['districts']);
    $districts = $districts->districts;
    return response()->json($districts);
  }

  public function edit($id) {
    $customer = Customer::find($id);
    $province = Indonesia::allProvinces()->pluck('name','id');
    
    $customer_province = DB::table('indonesia_provinces')->where('name', $customer->province)->get();
    $customer_province = $customer_province[0]->id;
    
    $city_customer = DB::table('indonesia_cities')->where('name', $customer->city)->get();
    $city_customer = $city_customer[0]->id;

    $district_customer = DB::table('indonesia_districts')->where('name', $customer->districts)->get();
    $district_customer = $district_customer[0]->id;
    
    $city = Indonesia::findProvince($customer_province, ['cities']);
    $city = $city->cities->pluck('name', 'id');

    $districts = Indonesia::findCity($city_customer, ['districts']);
    $districts = $districts->districts->pluck('name', 'id');

    return view('master/customer/modal_edit',compact(
                                                      'customer', 
                                                      'province', 
                                                      'customer_province', 
                                                      'city_customer', 
                                                      'city',
                                                      'district_customer',
                                                      'districts'
                                                    )
  );
    //return response()->json($city); 
  }

  public function update(Request $request, $id) {

    //$province = Provinces::find($request->input('province'));
    //$province = $province->name;

    $province = Indonesia::findProvince($request->input('province'));
    $province = $province->name;

    $city = Indonesia::findCity($request->input('city'), $with = null);
    $city = $city->name;

    $districts = Indonesia::findDistrict($request->input('districts'), $with = null);
    $districts = $districts->name;
    
    $customer = Customer::find($id);

    $this->validate($request, [
      'customer_number'   => 'required | unique:customer,customer_number,'.$customer->id,
      'name'              => 'required',
      'address'           => 'required',
      'province'          => 'required',
      'city'              => 'required',
      'phone'             => 'required',
      'npwp'              => 'required',
    ]);

    $customer->customer_number  = $request->customer_number;
    $customer->name             = $request->input('name');
    $customer->address          = $request->input('address');
    $customer->province         = $province;
    $customer->city             = $city;
    $customer->districts        = $districts;
    $customer->phone            = $request->input('phone');
    $customer->npwp  = $request->input('npwp');
    $customer->save();

    return response()->json(['responseText' => 'Updated'], 200);
    //return response()->json($city); 
  }

  public function destroy($id) {
    Customer::find($id)->delete();
    return response()->json(['responseText' => 'Deleted'], 200);
  }
}
