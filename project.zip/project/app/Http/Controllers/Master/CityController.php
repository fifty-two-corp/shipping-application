<?php

namespace App\Http\Controllers\Master;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Indonesia;
use App\Provinces;
use App\City;
use DB;
use Datatables;
use Carbon\Carbon;

class CityController extends Controller {
  
	public function index() {
		return view('master/city/index');
	}

  /*Province*/

 	public function getProvince(Request $request) {
 		//if($request->ajax())
      $province = Provinces::all();
 			return Datatables::of($province)
      ->editColumn('default_price', function ($province) {
        return $province->default_price? with("Rp " . number_format($province->default_price,0,',','.')) : '';
      })
      ->make(true);
 		//} else {
 		//	exit("Not an AJAX request -_-");
 		//}
 	}

 	public function createProvince() {
    return view('master/city/modal_add_province');
  }

  public function storeProvince(Request $request) {
    $this->validate($request, [
      'name'            => 'required',
      /*'default_price'   => 'required',*/
    ]);

    $default_price = str_replace(".", "", $request->input('default_price'));
    
    $province = new Provinces();
    $province->name              = $request->input('name');
    $province->default_price     = $default_price;
    $province->save();

    return response()->json(['responseText' => 'Success'], 200);

    //return response()->json($tax);
  }

  public function editProvince($id) {
    $province = Provinces::find($id);
    return view('master/city/modal_edit_province',compact('province'));
  }

  public function updateProvince(Request $request, $id) {
    $province = Provinces::find($id);
    $this->validate($request, [
      'name'            => 'required',
      'default_price'   => 'required',
    ]);

    $default_price = str_replace(".", "", $request->input('default_price'));
    
    $province->name              = $request->input('name');
    $province->default_price     = $default_price;
    $province->save();

    return response()->json(['responseText' => 'Updated'], 200);
    //return response()->json($province);
  }

  public function destroyProvince($id) {
    Provinces::find($id)->delete();
    return response()->json(['responseText' => 'Deleted'], 200);
  }

  /*City*/

  public function getCity($id) {
    //if($request->ajax())
      $city = Provinces::where('id', $id)->first();
      $city = $city->city;
      return Datatables::of($city)
      ->editColumn('unit_price', function ($city) {
        return $city->unit_price? with("Rp " . number_format($city->unit_price,0,',','.')) : '';
      })->make(true);
    //} else {
    //  exit("Not an AJAX request -_-");
    //}
  }

  public function getCityData($id) {
    return view('master/city/get-city-data', compact('id'));
  }

  public function getCityDefault() {
    return view('master/city/get-city-default');
  }

  public function createCity() {
    $province = Provinces::pluck('name', 'id');
    return view('master/city/modal_add_city', compact('province'));
  }

  public function storeCity(Request $request) {
    $this->validate($request, [
      'name'       => 'required',
      'province'   => 'required',
    ]);

    $unit_price = str_replace(".", "", $request->input('unit_price'));
    $province = $request->input('province');
    
    $city = new City();
    $city->name           = $request->input('name');
    $city->unit_price     = $unit_price;
    $city->save();
    $city->provinces()->attach($province);
    return response()->json(['responseText' => 'Success'], 200);
  }

  public function editCity($id) {
    $city = City::find($id);
    $province = Provinces::pluck('name','id');
    $province_city = $city->provinces->pluck('id', 'id')->toArray();
    return view('master/city/modal_edit_city',compact('city', 'province', 'province_city'));
  }

  public function updateCity(Request $request, $id) {
    $this->validate($request, [
      'name'        => 'required',
      'province'    => 'required',
    ]);

    $unit_price = str_replace(".", "", $request->input('unit_price'));
    $province = $request->input('province');
    
    $city = City::find($id);
    $city->name           = $request->input('name');
    $city->unit_price     = $unit_price;
    $city->save();
    DB::table('city_provinces')->where('city_id',$id)->delete();
    $city->provinces()->attach($province);

    return response()->json(['responseText' => 'Updated'], 200);
    //return response()->json($province);
  }

  public function destroyCity($id) {
    City::find($id)->delete();
    return response()->json(['responseText' => 'Deleted'], 200);
  }
}
