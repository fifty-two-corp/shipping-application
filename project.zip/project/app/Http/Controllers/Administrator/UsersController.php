<?php

namespace App\Http\Controllers\Administrator;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use App\Role;
use DB;
use Hash;
use Datatables;

class UsersController extends Controller {
  
	public function index() {
		return view('administrator/users/index');
	}

 	public function getUser(Request $request) {
 		if($request->ajax()){
      $users = User::with('roles');
 			return Datatables::of($users)->make(true);
 		} else {
 			exit("Not an AJAX request -_-");
 		}
 	}

 	public function create() {
    $roles = Role::pluck('display_name','id');
    return view('administrator/users/modal_add',compact('roles'));
 	}

  public function store(Request $request) {
    $this->validate($request, [
      'name'      => 'required',
      'username'  => 'required|unique:users,username',
      'email'     => 'required|email|unique:users,email',
      'password'  => 'required|same:confirm-password',
      'roles'     => 'required'
    ]);

    $input = $request->all();
    $input['password'] = Hash::make($input['password']);

    $user = User::create($input);
    $user->attachRole($request->input('roles'));
    
    
    return response()->json(['responseText' => 'Success'], 200);
  }

  public function edit($id) {
    $user = User::find($id);
    $roles = Role::pluck('display_name','id');
    $userRole = $user->roles->pluck('id','id')->toArray();

    return view('administrator/users/modal_edit',compact('user','roles','userRole'));
  }

  public function update(Request $request, $id) {
    $this->validate($request, [
        'name'      => 'required',
        'username'  => 'required|unique:users,username,'.$id,
        'email'     => 'required|email|unique:users,email,'.$id,
        'password'  => 'same:confirm-password',
        'roles'     => 'required'
    ]);

    $input = $request->all();
    if(!empty($input['password'])){ 
        $input['password'] = Hash::make($input['password']);
    }else{
        $input = array_except($input,array('password'));    
    }

    $user = User::find($id);
    $user->update($input);
    DB::table('role_user')->where('user_id',$id)->delete();
    $user->attachRole($request->input('roles'));
    

    return response()->json(['responseText' => 'Updated'], 200);
  }

  public function destroy($id) {
    User::find($id)->delete();
    return response()->json(['responseText' => 'Deleted'], 200);
  }
}
