<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChildMenu extends Model {
	protected $table = 'child_menu';

  public $fillable = ['id','name'];

  public function child_menu() {
      return $this->belongsToMany('App\Permission');
  }

  public function permission() {
    return $this->belongsToMany('App\Permission');
  }

  public function parent_menu() {
    return $this->belongsToMany('App\ParentMenu');
  }
}
