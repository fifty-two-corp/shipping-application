<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IdMethod extends Model
{
    protected $table = 'identity_method';
    protected $guard = [];
}
