<?php $__env->startSection('content'); ?>
<div id="content" class="content">        
    

  
            <div class="coming-soon">
            <div class="coming-soon-header">
                <div class="bg-cover"></div>
                <div class="brand">
                    <div class="timer">
                    <div id="timer"></div>
                </div>
                </div>
                
                <div class="desc">
                    Our page is almost there and it’s rebuilt from scratch! A lot of great new features <br />and improvements are coming.
                </div>
            </div>
            <div class="coming-soon-content">
                <div class="desc">
                    We are launching a closed <b>beta</b> soon!.
                </div>
                
               
                
            </div>
        </div>
      
    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>


<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>