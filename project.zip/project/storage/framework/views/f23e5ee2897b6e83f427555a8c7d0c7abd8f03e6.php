<div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            <h4 class="modal-title" id="modalVihicle">New Vehicle</h4>
        </div>
        <div class="modal-body">
            <?php echo Form::open(array('class' => 'form-horizontal', 'id' => 'form-vehicle-add')); ?>

              <div class="row">
                <div class="alert alert-danger fade in m-b-15" id="vehicle-allert" hidden>
                  <strong>Whoops!</strong> There were some problems with your input.
                  <span class="close" data-dismiss="alert">×</span>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                          <label class="col-md-3 control-label">Plat Number</label>
                          <div class="col-md-9">
                            <?php echo Form::text('plat_number', null, ['placeholder' => 'Plat Number','class' => 'form-control']); ?>

                          </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <label class="col-md-3 control-label">Name</label>
                            <div class="col-md-9">
                              <?php echo Form::text('name', null, ['placeholder' => 'Name','class' => 'form-control']); ?>

                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <label class="col-md-3 control-label">Driver</label>
                            <div class="col-md-9">
                              <?php echo Form::text('driver', null, ['placeholder' => 'Driver','class' => 'form-control']); ?>

                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <label class="col-md-3 control-label">Type</label>
                            <div class="col-md-9">
                              <?php echo Form::text('type', null, ['placeholder' => 'Type','class' => 'form-control']); ?>

                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <label class="col-md-3 control-label">Merk</label>
                            <div class="col-md-9">
                              <?php echo Form::text('merk', null, ['placeholder' => 'Merk','class' => 'form-control']); ?>

                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <label class="col-md-3 control-label">Color</label>
                            <div class="col-md-9">
                              <?php echo Form::text('color', null, ['placeholder' => 'Color','class' => 'form-control']); ?>

                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <label class="col-md-3 control-label">Production Year</label>
                            <div class="col-md-9">
                              <?php echo Form::text('production_year', null, ['placeholder' => 'Production Year','class' => 'form-control', 'id' => 'production']); ?>

                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <label class="col-md-3 control-label">Vehicle Tax</label>
                            <div class="col-md-9">
                              <?php echo Form::text('vehicle_tax', null, ['placeholder' => 'Vehicle Tax','class' => 'form-control', 'id' => 'tax']); ?>

                            </div>
                        </div>
                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <label class="col-md-3 control-label">Status</label>
                            <div class="col-md-9">
                              <?php echo Form::text('status', null, ['placeholder' => 'Status','class' => 'form-control']); ?>

                            </div>
                        </div>
                    </div>
                    
                  </div>
              </div>
              <?php echo Form::close(); ?>

             <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="btn-save" onclick="save_vehicle_data()">Save changes</button>
            </div>
        </div>
    </div>
</div>
<script>
    $('#tax').datepicker({
        format: "dd-mm-yyyy",
        language: "id",
        calendarWeeks: true,
        autoclose: true,
        todayHighlight: true,
        toggleActive: true
    });

    $("#production").datepicker( {
        format: " yyyy",
        viewMode: "years", 
        minViewMode: "years",
        autoclose: true,
        toggleActive: true
    });
</script>