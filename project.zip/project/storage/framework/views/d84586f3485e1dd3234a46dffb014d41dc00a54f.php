<div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            <h4 class="modal-title" id="modal_role">View Roles</h4>
        </div>
        <div class="modal-body">
              <div class="row">
                <div class="form-horizontal">               
                  <label class="col-xs-4 control-label">Name: </label>
                  <p class="form-control-static"><?php echo e($role->name); ?></p>             
                  <label class="col-xs-4 control-label">Display Name:</label>
                  <p class="form-control-static"><?php echo e($role->display_name); ?></p>              
                  <label class="col-xs-4 control-label">Description:</label>
                  <p class="form-control-static"><?php echo e($role->description); ?></p>             
                  <label class="col-xs-4 control-label">Created at:</label>
                  <p class="form-control-static"><?php echo e($role->created_at); ?></p>            
                  <label class="col-xs-4 control-label">Updated at</label>
                  <p class="form-control-static"><?php echo e($role->updated_at); ?></p>  
                  <label class="col-xs-4 control-label">Permission</label>
                  <p class="form-control-static">
                    <?php $__currentLoopData = $role_permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <span class="label label-success"><?php echo e($item); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </p>               
              </div>
              </div>
             <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>