<?php $__env->startSection('content'); ?>
<div id="content" class="content">        
    <!-- begin page-header -->
    <h1 class="page-header">Administrator <small></small></h1>
    <!-- end page-header -->

   <!-- begin row -->
    <div class="row">
            <!-- begin panel -->
      <div class="panel panel-inverse" data-sortable-id="form-stuff-5">
          <div class="panel-heading">
              <div class="panel-heading-btn">
                  <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
                  <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
              </div>
              <h4 class="panel-title">Users Management</h4>
          </div>
          <div class="panel-body">
            <div class="email-btn-row">
                <a href="javascript:;" id="btn_new" class="btn btn-sm btn-primary">New User</a>
                <a href="javascript:;" id="btn_view" class="btn btn-sm btn-default disabled btn_dynamic">View</a>
                <a href="javascript:;" id="btn_edit" class="btn btn-sm btn-default disabled btn_dynamic">Edit</a>
                <a href="javascript:;" id="btn_delete" class="btn btn-sm btn-default disabled btn_dynamic">Delete</a>
                <a href="javascript:;" onclick="reload_data()" class="btn btn-sm btn-success"><i class="fa fa-refresh"></i></a>
            </div>
            <hr>
            <div class="table-responsive">
              <table id="users_table" class="table table-striped display table-bordered responsive nowrap">
                  <thead>
                      <tr>
                          <th>#</th>
                          <th>Name</th>
                          <th>Email</th>
                          <th>Roles</th>
                          <th>Updated at</th>
                      </tr>
                  </thead>
              </table>
            </div>

              <!-- modal -->
              <div class="modal fade" id="modal-users" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                      <div class="modal-content">
                          <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                              <h4 class="modal-title" id="myModalLabel">New Users</h4>
                          </div>
                          <div class="modal-body">
                              <form id="frmTasks" name="frmTasks" class="form-horizontal" novalidate="">

                                  <div class="form-group error">
                                      <label for="inputTask" class="col-sm-3 control-label">Name</label>
                                      <div class="col-sm-9">
                                          <input type="text" class="form-control has-error" id="task" name="task" placeholder="Task" value="">
                                      </div>
                                  </div>

                                  <div class="form-group">
                                      <label for="inputEmail3" class="col-sm-3 control-label">Description</label>
                                      <div class="col-sm-9">
                                          <input type="text" class="form-control" id="description" name="description" placeholder="Description" value="">
                                      </div>
                                  </div>
                              </form>
                          </div>
                          <div class="modal-footer">
                              <button type="button" class="btn btn-primary" id="btn-save" value="add">Save changes</button>
                              <input type="hidden" id="task_id" name="task_id" value="0">
                          </div>
                      </div>
                  </div>
              </div><!-- end modal -->
          </div>
      </div><!-- end panel -->
    </div><!-- end row -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<!-- datatables -->
<script type="text/javascript">
  $('#administrator-menu').addClass('active');
  var listener = new window.keypress.Listener();
  $(document).ready(function() {
  userTable = $('#users_table').DataTable({
    processing: true,
    serverSide: true,
    ajax: {
      url:'<?php echo e(url("users/get-user")); ?>', 
      searchHighlight: true,
      deferRender: true,
    },
    deferRender: true,
    responsive:true,
    keys: true,
    sorting: [[0,"asc"]],
    pagingType: "full_numbers",
    dom:'C<"clear">lfrtip',
    stateSave: false,
    language: {
      "zeroRecords": "Reservation not found...",
      "loadingRecords": "Loading...",
      "processing": "Load Data"
    },
    columns: [
      { data: 'id', name: 'id' },
      { data: 'name', name: 'name' },
      { data: 'email', name: 'email' },
      { data: 'roles[, ].name', name: 'roles.name' },
      { data: 'updated_at', name: 'updated_at' }
    ]
  });

  $("#users_table tbody").on("click","tr",function() { //highlight on click row
    if ($(this).hasClass("active")) {
      $(this).removeClass("active");
      $("a.btn_dynamic").addClass("disabled");
      $("a#btn_view").removeClass("btn-info");
      $("a#btn_edit").removeClass("btn-warning");
      $("a#btn_delete").removeClass("btn-danger");
      $("a.btn_dynamic").addClass("btn-default");
    }
    else {
      userTable.$("tr.active").removeClass("active");
      $("a.btn_dynamic").addClass("disabled");
      $(this).addClass("active");
      $("a.btn_dynamic").removeClass("disabled");
      $("a.btn_dynamic").removeClass("btn-default");
      $("a#btn_view").addClass("btn-info");
      $("a#btn_edit").addClass("btn-warning");
      $("a#btn_delete").addClass("btn-danger");
    }
  });

  /*userTable.on("draw",function () {
    var body = $(userTable.table().body());
    body.unhighlight();
    body.highlight(userTable.search());
  });*/
  $("a#btn_new").click(function() {
    $('#modal-users').modal('show');
  });

  $("a#btn_view").click(function() { // Button Detail
    var data = userTable.row(".active").data();
    //console.log(data);
    var id = data["id"];
    //var member_id = data["member_id"];
    //var element = document.getElementById("#tab"+id);
    /*$.ajax({
        type:"GET",
        url: "reservation/ajax_get_reservation_detail/" +id+"/"+member_id,
        success: function(res) {
            if (element !== null) {
                $('#tabs .rtab'+id+'').tab('show');
                return false;
            }else if (id === ''){
                return false;
            } else {
                $('<li><a href="#tab'+id+'" data-toggle="tab" id="#tab'+id+'" class="rtab'+id+'"> '+
                    'Reservation #'+id+'&nbsp;&nbsp;&nbsp;<span class="text text-danger" id="close_tab"><i class="fa fa-times"></i></span></a></li>').appendTo('#tabs');       
                $(res).appendTo('.tab-content');
                $('#tabs .rtab'+id+'').tab('show');
                return false;
            }
        }
    });*/
  });

});





function reload_data() {
  userTable.ajax.reload(null,false);
  $("a.btn_dynamic").addClass("disabled");
  $("a#btn_view").removeClass("btn-info");
  $("a#btn_edit").removeClass("btn-warning");
  $("a#btn_delete").removeClass("btn-danger");
  $("a.btn_dynamic").addClass("btn-default");
}
</script>

<!-- ajax CRUD modal -->
<script>
    $(document).ready(function(){
        //TableManageResponsive.init();
        var url = "/ajax-crud/public/tasks";
        
        //display modal form for user editing
        $('.open-modal').click(function(){
        var task_id = $(this).val();

        $.get(url + '/' + task_id, function (data) {
            //success data
            console.log(data);
            $('#task_id').val(data.id);
            $('#task').val(data.task);
            $('#description').val(data.description);
            $('#btn-save').val("update");
            $('#myModal').modal('show');
        }) 
    });

    //display modal form for creating new task
    $('#btn-add').click(function(){
        $('#btn-save').val("add");
        $('#frmTasks').trigger("reset");
        $('#myModal').modal('show');
    });

    //delete task and remove it from list
    $('.delete-task').click(function(){
        var task_id = $(this).val();

        $.ajax({

            type: "DELETE",
            url: url + '/' + task_id,
            success: function (data) {
                console.log(data);

                $("#task" + task_id).remove();
            },
            error: function (data) {
                console.log('Error:', data);
            }
        });
    });

    //create new task / update existing task
    $("#btn-save").click(function (e) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        })

        e.preventDefault(); 

        var formData = {
            task: $('#task').val(),
            description: $('#description').val(),
        }

        //used to determine the http verb to use [add=POST], [update=PUT]
        var state = $('#btn-save').val();

        var type = "POST"; //for creating new resource
        var task_id = $('#task_id').val();;
        var my_url = url;

        if (state == "update"){
            type = "PUT"; //for updating existing resource
            my_url += '/' + task_id;
        }

        console.log(formData);

        $.ajax({
            type: type,
            url: my_url,
            data: formData,
            dataType: 'json',
            success: function (data) {
                console.log(data);
                var task = '<tr id="task' + data.id + '"><td>' + data.id + '</td><td>' + data.task + '</td><td>' + data.description + '</td><td>' + data.created_at + '</td>';
                task += '<td><button class="btn btn-warning btn-xs btn-detail open-modal" value="' + data.id + '">Edit</button>';
                task += '<button class="btn btn-danger btn-xs btn-delete delete-task" value="' + data.id + '">Delete</button></td></tr>';
                if (state == "add"){ //if user added a new record
                    $('#tasks-list').append(task);
                }else{ //if user updated an existing record

                    $("#task" + task_id).replaceWith( task );
                }

                $('#frmTasks').trigger("reset");
                $('#myModal').modal('hide')
            },
            error: function (data) {
                console.log('Error:', data);
            }
        });
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>