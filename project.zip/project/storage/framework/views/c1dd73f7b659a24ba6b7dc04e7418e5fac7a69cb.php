<?php $__env->startSection('content'); ?>
<div id="content" class="content">        
    <!-- begin page-header -->
    <h1 class="page-header">Master <small></small></h1>
    <!-- end page-header -->

   <!-- begin row -->
    <div class="row">
            <!-- begin panel -->
      <div class="panel panel-inverse" data-sortable-id="form-stuff-5">
          <div class="panel-heading">
              <div class="panel-heading-btn">
                  <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
                  <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
              </div>
              <h4 class="panel-title">Employess</h4>
          </div>
          <div class="panel-body">
            <div class="email-btn-row">
                <a href="javascript:;" id="btn_new" class="btn btn-sm btn-primary" onclick="show_modal_add_employess()">New Employess</a>
                <a href="javascript:;" id="btn_view" class="btn btn-sm btn-default disabled btn_dynamic" onclick="show_modal_view_employess()">View</a>
                <a href="javascript:;" id="btn_edit" class="btn btn-sm btn-default disabled btn_dynamic" onclick="show_modal_edit_employess()">Edit</a>
                <a href="javascript:;" id="btn_delete" class="btn btn-sm btn-default disabled btn_dynamic" onclick="delete_employess()">Delete</a>
                <a href="javascript:;" onclick="reload_data()" class="btn btn-sm btn-success"><i class="fa fa-refresh"></i></a>
            </div>
            <hr>
            <div class="table-responsive">
              <table id="employess_table" class="table table-striped display table-bordered responsive nowrap">
                  <thead>
                      <tr>
                          <th>#</th>
                          <th>Employess Number</th>
                          <th>Name</th>
                          <th>Address</th>
                          <th>Province</th>
                          <th>City</th>
                          <th>Phone</th>
                          <th>Create at</th>
                          <th>Update at</th>
                      </tr>
                  </thead>
              </table>
            </div>
            <div class="modal fade" id="modal_employess" tabindex="-1" role="dialog" aria-labelledby="modal_employess" aria-hidden="true"></div>
          </div>
      </div><!-- end panel -->
    </div><!-- end row -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<!-- datatables -->
<script type="text/javascript">
  $('#master-menu').addClass('active');
  var listener = new window.keypress.Listener();
  $(document).ready(function() {
  employessTable = $('#employess_table').DataTable({
    processing: true,
    serverSide: true,
    ajax: {
      url:'<?php echo e(url("employess/get-employess")); ?>', 
      searchHighlight: true,
      deferRender: true,
    },
    deferRender: true,
    responsive:true,
    keys: true,
    sorting: [[0,"asc"]],
    pagingType: "full_numbers",
    dom:'C<"clear">lfrtip',
    stateSave: false,
    language: {
      "zeroRecords": "employess not found...",
      "loadingRecords": "Loading...",
      "processing": "Load Data"
    },
    columns: [
      { data: 'id', name: 'id' },
      { data: 'employess_number', name: 'employess_number' },
      { data: 'name', name: 'name' },
      { data: 'address', name: 'address' },
      { data: 'province', name: 'province' },
      { data: 'city', name: 'city' },
      { data: 'phone', name: 'phone' },
      { data: 'created_at', name: 'created_at' },
      { data: 'updated_at', name: 'updated_at' }
    ]
  });

  $("#employess_table tbody").on("click","tr",function() { //highlight on click row
    if ($(this).hasClass("active")) {
      $(this).removeClass("active");
      $("a.btn_dynamic").addClass("disabled");
      $("a#btn_view").removeClass("btn-info");
      $("a#btn_edit").removeClass("btn-warning");
      $("a#btn_delete").removeClass("btn-danger");
      $("a.btn_dynamic").addClass("btn-default");
    }
    else {
      employessTable.$("tr.active").removeClass("active");
      $("a.btn_dynamic").addClass("disabled");
      $(this).addClass("active");
      $("a.btn_dynamic").removeClass("disabled");
      $("a.btn_dynamic").removeClass("btn-default");
      $("a#btn_view").addClass("btn-info");
      $("a#btn_edit").addClass("btn-warning");
      $("a#btn_delete").addClass("btn-danger");
    }
  });
});


function show_modal_add_employess() {
  $.ajax({
    type:"GET",
    url: "employess/create",
    success: function(res) {
      $('#modal_employess').html(res);
      $('#modal_employess').modal('show');
    }
  });
}

function show_modal_edit_employess() {
  var data = employessTable.row(".active").data();
  var id = data["id"];
  $.ajax({
    type:"GET",
    url: "employess/"+id+"/edit",
    success: function(res) {
      //console.log(res);
      $('#modal_employess').modal('show');
      $('#modal_employess').html(res);
    }
  });
}

function save_employess_data(){
  $.ajaxSetup({
    header:$('meta[name="_token"]').attr('content')
  })
  //e.preventDefault(e);
  $.ajax({
    type:"POST",
    url:'employess/store',
    data:$('#form-employess-add').serialize(),
    dataType: 'json',
    success: function(data){
      $('#modal_employess').modal('hide');
      swal('Added','','success');
      reload_data();
    },
      error: function(data){
        $('#employess-allert').removeAttr('hidden');
    }
  })
};


function save_edit_employess_data(){
  var data = employessTable.row(".active").data();
  var id = data["id"];
  $.ajaxSetup({
    header:$('meta[name="_token"]').attr('content')
  })
  $.ajax({
    type:"PATCH",
    url:'employess/'+id,
    data:$('#form-edit-employess').serialize(),
    
    success: function(data){
      //console.log(data);
      $('#modal_employess').modal('hide');
      swal('Updated','','success');
      reload_data();
    },
      error: function(data){
        $('#employess-allert').removeAttr('hidden');
    }
  })
};

function delete_employess() {
  var data = employessTable.row(".active").data();
  var name = data["name"];
  var id = data["id"];

  swal({
    title: 'Are you sure?',
    text: "You won't be able to revert this!",
    type: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes, delete it!'
  }).then(function () {
      $.ajax({
      type:"DELETE",
      url:'employess/'+id,
      dataType: 'json',
      success: function(data){
        //console.log(data);
        swal('Deleted!','Your data has been deleted.','success');
        reload_data();
      },
      error: function(data){
        swal('Error','Someting Wrong','error');
      }
    })
  })
}

function reload_data() {
  employessTable.ajax.reload(null,false);
  $("a.btn_dynamic").addClass("disabled");
  $("a#btn_view").removeClass("btn-info");
  $("a#btn_edit").removeClass("btn-warning");
  $("a#btn_delete").removeClass("btn-danger");
  $("a.btn_dynamic").addClass("btn-default");
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>