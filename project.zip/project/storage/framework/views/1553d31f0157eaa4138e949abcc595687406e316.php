<!-- begin scroll to top btn -->
<a href="javascript:;" class="btn btn-icon btn-circle btn-success btn-scroll-to-top fade" data-click="scroll-top"><i class="fa fa-angle-up"></i></a>
<!-- end scroll to top btn -->
</div>
	<!-- end page container -->
<!-- ================== BEGIN BASE JS ================== -->
<script src="<?php echo e(asset('plugins/jquery/jquery-1.9.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jquery/jquery-migrate-1.1.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jquery-ui/ui/minified/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>
<!--[if lt IE 9]>
	<script src="<?php echo e(asset('crossbrowserjs/html5shiv.js')); ?>"></script>
	<script src="<?php echo e(asset('crossbrowserjs/respond.min.js')); ?>"></script>
	<script src="<?php echo e(asset('crossbrowserjs/excanvas.min.js')); ?>"></script>
<![endif]-->
<script src="<?php echo e(asset('plugins/slimscroll/jquery.slimscroll.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jquery-cookie/jquery.cookie.js')); ?>"></script>
<!-- ================== END BASE JS ================== -->
	
<!-- ================== BEGIN PAGE LEVEL JS ================== -->
<script src="<?php echo e(asset('plugins/flot/jquery.flot.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/flot/jquery.flot.time.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/flot/jquery.flot.resize.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/flot/jquery.flot.pie.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/sparkline/jquery.sparkline.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jquery-jvectormap/jquery-jvectormap-1.2.2.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jquery-jvectormap/jquery-jvectormap-world-mill-en.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap-datepicker/js/bootstrap-datepicker.js')); ?>"></script>
<script src="<?php echo e(asset('js/dashboard.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/DataTables/js/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/DataTables/js/dataTables.responsive.js')); ?>"></script>
<script src="<?php echo e(asset('js/ui-modal-notification.demo.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/apps.min.js')); ?>"></script>
<!-- ================== END PAGE LEVEL JS ================== -->